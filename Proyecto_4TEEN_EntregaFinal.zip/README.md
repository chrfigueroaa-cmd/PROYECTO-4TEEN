**Nombre de Proyecto:** 

4TEEN 



**Equipo**:

Samuel Sanchez Badillo

Christian Figueroa Arenas



**Descripción de sistema:**

Sistema de gestion de inventario y generación de ventas, con posibilidad de registrar clientes, agregar productos y emitir boletas o una factura asociada a un cliente.



**Instalación**:

1. Importar la BD compartida
2. Abrir XAMPP y iniciar los módulos Apache y MySQL
3. Descomprimir el archivo .zip
4. Abrir el ejecutable .jar (Proyecto\_4TEEN\_SEGUIR)
5. Disfrutar de nuestro sistema





