/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import controlador.Controlador;
import java.awt.HeadlessException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import modelo.Cliente;
import modelo.Producto;

/**
 *
 * @author chifr
 */
public class Form_GenerarVentaFactura extends javax.swing.JFrame {

    private DefaultTableModel modeloTabla;
    private double totalAcumulado = 0.0;

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Form_GenerarVentaFactura.class.getName());

    /**
     * Creates new form Form_GenerarVentaFactura
     */
    public Form_GenerarVentaFactura() {
        initComponents();
        cargarClientes();
        cargarProductos();

        modeloTabla = new DefaultTableModel(
                new Object[]{"Producto", "Precio Unit", "Cantidad", "Total"}, 0
        );
        jtbl_datos.setModel(modeloTabla);
        jtbl_datos.setDefaultEditor(Object.class, null);

        jcb_productos.addActionListener(e -> actualizarSpinnerSegunProducto());
        jsp_cantidad.setValue(1);
    }

    private void recalcularTotal() {
        DefaultTableModel model = (DefaultTableModel) jtbl_datos.getModel();
        double total = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            total += (double) model.getValueAt(i, 3);
        }

        jLabel6.setText("$" + total);
    }

    private void cargarClientes() {
        Controlador con = new Controlador();
        List<Cliente> lista = con.buscarClientes();

        jcb_cliente.removeAllItems();
        for (Cliente c : lista) {
            jcb_cliente.addItem(c);
        }
    }

    private void cargarProductos() {
        Controlador con = new Controlador();
        List<Producto> lista = con.buscarProductos();

        jcb_productos.removeAllItems();
        for (Producto p : lista) {
            jcb_productos.addItem(p);
        }
    }

    private void actualizarSpinnerSegunProducto() {
        Producto p = (Producto) jcb_productos.getSelectedItem();

        if (p == null) {
            return;
        }

        int stock = p.getStock();

        if (stock <= 0) {
            jsp_cantidad.setModel(new SpinnerNumberModel(0, 0, 0, 1));
            return;
        }

        jsp_cantidad.setModel(new SpinnerNumberModel(1, 1, stock, 1));
    }

    private void actualizarTotal() {
        DefaultTableModel model = (DefaultTableModel) jtbl_datos.getModel();
        double total = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            total += (double) model.getValueAt(i, 3);
        }

        jLabel6.setText("$" + total);
    }

    private void agregarItemTabla() {
        try {
            Producto p = (Producto) jcb_productos.getSelectedItem();
            if (p == null) {
                JOptionPane.showMessageDialog(this, "Seleccione un producto.");
                return;
            }

            int id = p.getIdProducto();
            String nombre = p.getNombre();
            double precio = p.getPrecioNeto();
            int stock = p.getStock();

            int cantidad = (int) jsp_cantidad.getValue();

            if (cantidad <= 0) {
                JOptionPane.showMessageDialog(this, "La cantidad debe ser mayor a 0.");
                return;
            }

            if (cantidad > stock) {
                JOptionPane.showMessageDialog(this, "La cantidad supera el stock disponible.");
                return;
            }

            DefaultTableModel modelo = (DefaultTableModel) jtbl_datos.getModel();

            // Verificar si el producto ya existe en la tabla
            for (int i = 0; i < modelo.getRowCount(); i++) {

                Producto existente = (Producto) modelo.getValueAt(i, 0);

                // 🚨 AGREGADO: si la fila está vacía, continuar
                if (existente == null) {
                    continue;
                }

                if (existente.getIdProducto() == id) {
                    int cantidadActual = (int) modelo.getValueAt(i, 2);
                    int nuevaCantidad = cantidadActual + cantidad;

                    if (nuevaCantidad > stock) {
                        JOptionPane.showMessageDialog(this, "Supera el stock disponible.");
                        return;
                    }

                    double nuevoTotal = nuevaCantidad * precio;

                    modelo.setValueAt(nuevaCantidad, i, 2);
                    modelo.setValueAt(nuevoTotal, i, 3);
                    actualizarTotal();
                    return;
                }
            }

            // Si no está en la tabla, agregarlo
            double total = precio * cantidad;

            modelo.addRow(new Object[]{
                p, // objeto Producto
                precio,
                cantidad,
                total
            });

            actualizarTotal();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al agregar producto: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jbtn_vender = new javax.swing.JButton();
        jbtn_limpiar = new javax.swing.JButton();
        jbtn_inicio = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jcb_cliente = new javax.swing.JComboBox<>();
        jcb_productos = new javax.swing.JComboBox<>();
        jsp_cantidad = new javax.swing.JSpinner();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtbl_datos = new javax.swing.JTable();
        jbtn_agregar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Venta Factura");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Impact", 0, 60)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/IMG_4538.PNG"))); // NOI18N

        jbtn_vender.setBackground(new java.awt.Color(141, 147, 171));
        jbtn_vender.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jbtn_vender.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/attach_money_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"))); // NOI18N
        jbtn_vender.setText("Vender");
        jbtn_vender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_venderActionPerformed(evt);
            }
        });

        jbtn_limpiar.setBackground(new java.awt.Color(141, 147, 171));
        jbtn_limpiar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jbtn_limpiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cleaning_services_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24 (1).png"))); // NOI18N
        jbtn_limpiar.setText("Limpiar");
        jbtn_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_limpiarActionPerformed(evt);
            }
        });

        jbtn_inicio.setBackground(new java.awt.Color(141, 147, 171));
        jbtn_inicio.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jbtn_inicio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/home.png"))); // NOI18N
        jbtn_inicio.setText("Inicio");
        jbtn_inicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_inicioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jbtn_vender, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jbtn_limpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jbtn_inicio, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGap(32, 32, 32)
                .addComponent(jbtn_vender)
                .addGap(18, 18, 18)
                .addComponent(jbtn_limpiar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 128, Short.MAX_VALUE)
                .addComponent(jbtn_inicio)
                .addGap(56, 56, 56))
        );

        jLabel2.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        jLabel2.setText("Factura");

        jLabel3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel3.setText("Cliente");

        jcb_cliente.setModel(new javax.swing.DefaultComboBoxModel());

        jcb_productos.setModel(new javax.swing.DefaultComboBoxModel());

        jLabel4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel4.setText("Producto");

        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel5.setText("Cantidad");

        jtbl_datos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Producto", "Precio Unit", "Cantidad", "Precio Total"
            }
        ));
        jScrollPane2.setViewportView(jtbl_datos);

        jbtn_agregar.setText("Agregar");
        jbtn_agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_agregarActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel6.setText("$0");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(164, 164, 164)
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(64, 64, 64)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel4)
                                                .addGap(173, 173, 173))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jcb_productos, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jcb_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel5)
                                                .addGap(28, 28, 28))
                                            .addComponent(jsp_cantidad)
                                            .addComponent(jbtn_agregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(72, 72, 72)))
                        .addGap(30, 30, 30))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jcb_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtn_agregar))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jcb_productos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jsp_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addGap(16, 16, 16))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbtn_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_limpiarActionPerformed
        DefaultTableModel model = (DefaultTableModel) jtbl_datos.getModel();
        model.setRowCount(0);

        jLabel6.setText("$0");
        jsp_cantidad.setValue(1);
    }//GEN-LAST:event_jbtn_limpiarActionPerformed

    private void jbtn_inicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_inicioActionPerformed
        this.dispose();
    }//GEN-LAST:event_jbtn_inicioActionPerformed

    private void jbtn_venderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_venderActionPerformed
        if (modeloTabla.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No hay productos en el carrito.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Cliente clienteSeleccionado = (Cliente) jcb_cliente.getSelectedItem();
        if (clienteSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Seleccione un cliente.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Controlador con = new Controlador();

        try {
            // Recalcular totalAcumulado antes de generar la venta
            totalAcumulado = 0;
            int cantidadTotal = 0;
            for (int i = 0; i < modeloTabla.getRowCount(); i++) {
                cantidadTotal += Integer.parseInt(modeloTabla.getValueAt(i, 2).toString());
                totalAcumulado += Double.parseDouble(modeloTabla.getValueAt(i, 3).toString());
            }

            int idVenta = con.crearVentaConCliente(totalAcumulado, cantidadTotal, clienteSeleccionado.getIdCliente());

            for (int i = 0; i < modeloTabla.getRowCount(); i++) {
                Producto p = (Producto) modeloTabla.getValueAt(i, 0);
                int cantidad = Integer.parseInt(modeloTabla.getValueAt(i, 2).toString());
                double totalFila = Double.parseDouble(modeloTabla.getValueAt(i, 3).toString());

                con.agregarDetalleVenta(idVenta, p.getIdProducto(), cantidad, p.getPrecioNeto(), totalFila);

                // Actualizar stock en la base de datos
                con.actualizarStock(p.getIdProducto(), p.getStock() - cantidad);
            }

            JOptionPane.showMessageDialog(this, "Venta realizada con éxito.");

            String metodoPago = "Efectivo";
            String tipoComprobante = "FACTURA ELECTRÓNICA";

            // Abrir recibo con el total correcto
            Form_Recibo fr = new Form_Recibo(
                    idVenta,
                    jtbl_datos,
                    totalAcumulado,
                    metodoPago,
                    tipoComprobante
            );

            fr.setLocationRelativeTo(null);
            fr.setVisible(true);

            // Limpiar tabla y formulario
            modeloTabla.setRowCount(0);
            totalAcumulado = 0;
            jLabel6.setText("$0");
            jsp_cantidad.setValue(1);

            cargarProductos();
            cargarClientes();

        } catch (HeadlessException | NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error al procesar la venta: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jbtn_venderActionPerformed

    private void jbtn_agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_agregarActionPerformed
        agregarItemTabla();
        actualizarTotal();
    }//GEN-LAST:event_jbtn_agregarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Form_GenerarVentaFactura().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton jbtn_agregar;
    private javax.swing.JButton jbtn_inicio;
    private javax.swing.JButton jbtn_limpiar;
    private javax.swing.JButton jbtn_vender;
    private javax.swing.JComboBox<modelo.Cliente> jcb_cliente;
    private javax.swing.JComboBox<modelo.Producto> jcb_productos;
    private javax.swing.JSpinner jsp_cantidad;
    private javax.swing.JTable jtbl_datos;
    // End of variables declaration//GEN-END:variables
}
