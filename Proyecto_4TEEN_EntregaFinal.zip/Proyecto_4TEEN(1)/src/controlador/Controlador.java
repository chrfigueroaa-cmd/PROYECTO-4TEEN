package controlador;

import bd.Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Cliente;
import modelo.Producto;

/**
 *
 * @author Christian Figueroa
 * @author Samuel Sanchez
 * @version 11-11-2025
 */
public class Controlador {

    public boolean agregarCliente(Cliente cliente) {

        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "INSERT INTO cliente(nombre,rut,razonSocial,correo,telefono)VALUES(?,?,?,?,?)";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setString(1, cliente.getNombre());
            stmt.setString(2, cliente.getRut());
            stmt.setString(3, cliente.getRazonSocial());
            stmt.setString(4, cliente.getCorreo());
            stmt.setInt(5, cliente.getTelefono());

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error en SQL al agregar Cliente " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarCliente(int idCliente) {

        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "DELETE FROM cliente WHERE idCliente = ? ";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setInt(1, idCliente);

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error en SQL al eliminar Cliente " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarCliente(Cliente cliente) {
        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "UPDATE cliente SET nombre = ?, rut = ?, razonSocial = ?, correo = ?, telefono = ? WHERE idCliente = ?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setString(1, cliente.getNombre());
            stmt.setString(2, cliente.getRut());
            stmt.setString(3, cliente.getRazonSocial());
            stmt.setString(4, cliente.getCorreo());
            stmt.setInt(5, cliente.getTelefono());
            stmt.setInt(6, cliente.getIdCliente());

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error en SQL al actualizar Cliente " + e.getMessage());
            return false;
        }
    }

    public List<Cliente> buscarClientes() {

        List<Cliente> lista = new ArrayList<>();

        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "select * from cliente order by nombre";
            PreparedStatement stmt = cnx.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setIdCliente(rs.getInt("idCliente"));
                cliente.setNombre(rs.getString("nombre"));
                cliente.setRut(rs.getString("rut"));
                cliente.setRazonSocial(rs.getString("razonSocial"));
                cliente.setCorreo(rs.getString("correo"));
                cliente.setTelefono(rs.getInt("telefono"));
                lista.add(cliente);
            }
            rs.close();
            stmt.close();
            cnx.close();
        } catch (SQLException e) {
            System.out.println("Error en SQL al consultar Cliente " + e.getMessage());
        }
        return lista;
    }

    public Cliente buscarClientePorId(int idCliente) {

        Cliente cliente = null;

        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "select * from cliente where idCliente = ?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setInt(1, idCliente);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                cliente = new Cliente();
                cliente.setIdCliente(rs.getInt("idCliente"));
                cliente.setNombre(rs.getString("nombre"));
                cliente.setRut(rs.getString("rut"));
                cliente.setRazonSocial(rs.getString("razonSocial"));
                cliente.setCorreo(rs.getString("correo"));
                cliente.setTelefono(rs.getInt("telefono"));
            }

            rs.close();
            stmt.close();
            cnx.close();

        } catch (SQLException e) {
            System.out.println("Error en SQL al consultar Cliente por ID" + e.getMessage());
        }
        return cliente;
    }

    public boolean agregarProducto(Producto producto) {
        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "INSERT INTO producto(nombre,categoria,stock,precioNeto,disponible)VALUES(?,?,?,?,?)";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setString(1, producto.getNombre());
            stmt.setString(2, producto.getCategoria());
            stmt.setInt(3, producto.getStock());
            stmt.setDouble(4, producto.getPrecioNeto());
            stmt.setBoolean(5, producto.isDisponible());

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error en SQL al agregar Producto " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarProducto(int idProducto) {
        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "UPDATE producto SET disponible = 0 WHERE idProducto = ?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setInt(1, idProducto);

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error en SQL al desactivar Producto " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarProducto(Producto producto) {
        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "UPDATE producto set nombre = ?, categoria = ?, stock = ?, precioNeto = ?, disponible = ? WHERE idProducto = ?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setString(1, producto.getNombre());
            stmt.setString(2, producto.getCategoria());
            stmt.setInt(3, producto.getStock());
            stmt.setDouble(4, producto.getPrecioNeto());
            stmt.setBoolean(5, producto.isDisponible());
            stmt.setInt(6, producto.getIdProducto());

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error en SQL al actualizar Producto " + e.getMessage());
            return false;
        }
    }

    public List<Producto> buscarProductos() {
        List<Producto> lista = new ArrayList<>();

        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "select * from producto order by idProducto";
            PreparedStatement stmt = cnx.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Producto producto = new Producto();
                producto.setIdProducto(rs.getInt("idProducto"));
                producto.setNombre(rs.getString("nombre"));
                producto.setCategoria(rs.getString("categoria"));
                producto.setStock(rs.getInt("stock"));
                producto.setPrecioNeto(rs.getDouble("precioNeto"));
                producto.setDisponible(rs.getBoolean("disponible"));
                lista.add(producto);
            }
            rs.close();
            stmt.close();
            cnx.close();
        } catch (SQLException e) {
            System.out.println("Error en SQL al consultar Producto " + e.getMessage());
        }
        return lista;
    }

    public Producto buscarProductoPorId(int idProducto) {
        Producto producto = new Producto();

        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "select * from producto where idProducto = ?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setInt(1, idProducto);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                producto.setIdProducto(rs.getInt("idProducto"));
                producto.setNombre(rs.getString("nombre"));
                producto.setCategoria(rs.getString("categoria"));
                producto.setStock(rs.getInt("stock"));
                producto.setPrecioNeto(rs.getDouble("precioNeto"));
                producto.setDisponible(rs.getBoolean("disponible"));
            }

            rs.close();
            stmt.close();
            cnx.close();
        } catch (SQLException e) {
            System.out.println("Error en SQL al consultar Producto por ID" + e.getMessage());
        }
        return producto;
    }

    public boolean descontarStock(int idProducto, int cantidadVendida) {
        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "UPDATE producto SET stock = stock - ? WHERE idProducto = ?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setInt(1, cantidadVendida);
            stmt.setInt(2, idProducto);

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error en SQL al descontar stock: " + e.getMessage());
            return false;
        }
    }

    public Producto buscarProductoPorNombre(String nombre) {
        Producto producto = null;

        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "SELECT * FROM producto WHERE nombre = ?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setString(1, nombre);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                producto = new Producto();
                producto.setIdProducto(rs.getInt("idProducto"));
                producto.setNombre(rs.getString("nombre"));
                producto.setCategoria(rs.getString("categoria"));
                producto.setStock(rs.getInt("stock"));
                producto.setPrecioNeto(rs.getDouble("precioNeto"));
                producto.setDisponible(rs.getBoolean("disponible"));
            }

            rs.close();
            stmt.close();
            cnx.close();

        } catch (SQLException e) {
            System.out.println("Error en SQL al consultar Producto por nombre: " + e.getMessage());
        }

        return producto;
    }

    public List<Producto> buscarProductosConStock() {
        List<Producto> lista = new ArrayList<>();

        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "SELECT * FROM producto WHERE stock > 0 ORDER BY nombre";
            PreparedStatement stmt = cnx.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Producto p = new Producto();
                p.setIdProducto(rs.getInt("idProducto"));
                p.setNombre(rs.getString("nombre"));
                p.setCategoria(rs.getString("categoria"));
                p.setStock(rs.getInt("stock"));
                p.setPrecioNeto(rs.getDouble("precioNeto"));
                p.setDisponible(rs.getBoolean("disponible"));
                lista.add(p);
            }

            rs.close();
            stmt.close();
            cnx.close();

        } catch (SQLException e) {
            System.out.println("Error en SQL al consultar productos con stock: " + e.getMessage());
        }

        return lista;
    }

    public int crearVenta(double total, int cantidadTotal) {
        int idGenerado = -1;

        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "INSERT INTO venta(total, cantidadTotal) VALUES (?,?)";
            PreparedStatement stmt = cnx.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

            stmt.setDouble(1, total);
            stmt.setInt(2, cantidadTotal);

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                idGenerado = rs.getInt(1);
            }

            rs.close();
            stmt.close();
            cnx.close();

        } catch (SQLException e) {
            System.out.println("Error al crear venta: " + e.getMessage());
        }

        return idGenerado;
    }

    public double obtenerTotalVentas() {
        double total = 0;
        String sql = "SELECT SUM(totalVenta) FROM venta"; // o como esté tu columna de total
        // ejecutar query y devolver total
        return total;
    }

    public boolean agregarDetalleVenta(int idVenta, int idProducto, int cantidad, double precioUnitario, double subtotal) {
        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String sql = "INSERT INTO detalle_venta(idVenta, idProducto, cantidad, precioUnitario, subtotal) VALUES (?,?,?,?,?)";
            PreparedStatement stmt = cnx.prepareStatement(sql);
            stmt.setInt(1, idVenta);
            stmt.setInt(2, idProducto);
            stmt.setInt(3, cantidad);
            stmt.setDouble(4, precioUnitario);
            stmt.setDouble(5, subtotal);

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al agregar detalle venta: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarStock(int idProducto, int cantidadVendida) {
        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String sql = "UPDATE producto SET stock = stock - ? WHERE idProducto = ?";
            PreparedStatement stmt = cnx.prepareStatement(sql);
            stmt.setInt(1, cantidadVendida);
            stmt.setInt(2, idProducto);

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al actualizar stock: " + e.getMessage());
            return false;
        }
    }

    public int crearVentaConCliente(double total, int cantidadTotal, int idCliente) {
        int idGenerado = -1;

        try {
            Conexion con = new Conexion();
            Connection cnx = con.obtenerConexion();

            String query = "INSERT INTO venta(idCliente, total, cantidadTotal) VALUES (?,?,?)";
            PreparedStatement stmt = cnx.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

            stmt.setInt(1, idCliente);
            stmt.setDouble(2, total);
            stmt.setInt(3, cantidadTotal);

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                idGenerado = rs.getInt(1);
            }

            rs.close();
            stmt.close();
            cnx.close();

        } catch (SQLException e) {
            System.out.println("Error al crear venta con cliente: " + e.getMessage());
        }

        return idGenerado;
    }

}
