
package controlador;

/**
 *
 * @author Christian Figueroa
 * @author Samuel Sanchez
 * @version 11-11-2025
 */

public class Venta {
    
    
    
}
