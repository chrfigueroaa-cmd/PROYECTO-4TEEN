package modelo;

/**
 *
 * @author Christian Figueroa
 * @author Samuel Sanchez
 * @version 11-11-2025
 */
public class Producto {

    private int idProducto;
    private String nombre, categoria;
    private int stock;
    private double precioNeto;
    private boolean disponible;

    public Producto() {
    }

    public Producto(int idProducto, String nombre, String categoria, int stock, double precioNeto, boolean disponible) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.categoria = categoria;
        this.stock = stock;
        this.precioNeto = precioNeto;
        this.disponible = disponible;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public double getPrecioNeto() {
        return precioNeto;
    }

    public void setPrecioNeto(double precioNeto) {
        this.precioNeto = precioNeto;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    @Override
    public String toString() {
        return nombre;
    }

}
