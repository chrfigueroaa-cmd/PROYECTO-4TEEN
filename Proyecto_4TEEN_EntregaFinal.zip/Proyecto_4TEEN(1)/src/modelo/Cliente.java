
package modelo;

/**
 *
 * @author Christian Figueroa
 * @author Samuel Sanchez
 * @version 11-11-2025
 */
public class Cliente {
    
    private int idCliente,telefono;
    private String nombre,rut,correo,razonSocial;

    public Cliente() {
    }

    public Cliente(int idCliente, int telefono, String nombre, String rut, String correo, String razonSocial) {
        this.idCliente = idCliente;
        this.telefono = telefono;
        this.nombre = nombre;
        this.rut = rut;
        this.correo = correo;
        this.razonSocial = razonSocial;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    @Override
    public String toString() {
        return nombre;
    }

    
}
