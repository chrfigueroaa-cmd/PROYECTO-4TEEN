Nombre de Proyecto: 
4TEEN 

Equipo:
Samuel Sanchez Badillo
Christian Figueroa Arenas

Descripción de sistema:
Sistema de gestion de inventario y generación de ventas, con posibilidad de registrar clientes, agregar productos y emitir boletas o una factura asociada a un cliente.

Instalación:
Importar la BD compartida
Abrir XAMPP y iniciar los módulos Apache y MySQL
Descomprimir el archivo .zip
Abrir el ejecutable .jar (Proyecto_4TEEN_SEGUIR)
Disfrutar de nuestro sistema

